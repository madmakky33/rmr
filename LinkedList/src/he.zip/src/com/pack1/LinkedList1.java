package com.pack1;

public class LinkedList1
{
	public static void main(String[] args)
	{
		System.out.println("hello to all");
	}
}