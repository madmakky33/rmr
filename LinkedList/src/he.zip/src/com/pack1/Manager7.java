package com.pack1;

public class Manager7
{
	public static void main(String[] args)
	{
		
	}
	public void test()
	{
		System.out.println("done");
	}
	private int test(int i)
	{
		return 0;
	}
}